# Detector provenance and limits

This headless package transfers the current Surfare prototype's rules, provider prompts and compact SMS model without retraining or threshold changes. The original project is https://github.com/alvarKaixer/surfare-prototype . Its research scripts and historical benchmark reports are not required runtime dependencies and are not imported here.

## Offline model

The model in `lib/models/sms-model.json` was trained from:

1. Almeida, T. & Hidalgo, J. (2011), UCI SMS Spam Collection, DOI https://doi.org/10.24432/C5CC84 , CC BY 4.0.
2. Alexander / Yissuh (2023), Filipino-Spam-SMS-Detection-Model, https://github.com/Yissuh/Filipino-Spam-SMS-Detection-Model , BSD-3-Clause.

Attribution and the preserved BSD license are in `public/licenses/`. Preparation normalized Unicode, masked URLs/numbers for template grouping, removed duplicate normalized templates and conflicting labels, then assigned fixed SHA-256 train/validation/test partitions (70/15/15). Training used unigram/bigram features and naive Bayes coefficients. Runtime inference uses `lib/sms-features.js` and `lib/sms-model.js`.

Spam/ham labels do not establish verified fraud, personal danger or sender identity. The standalone classifier's prior 97.44% score on 860 held-out SMS labels is historical evidence, not a current full-app accuracy claim. Its raw frozen corpus is absent from this import. Development-informed rules were also informed by separate message data with noisy scam/spam categories; those data and any upstream models are not redistributed.

## Current policy

- Local patterns detect combined requests and context, threats, coercion, suspicious URLs and learned spam-like wording. Text is normalized consistently for rules, SMS features and dataset matching, so dotted or leet-spelled secrets (`O.T.P`, `t1me p4ssw0rd`) stay reviewable while highlights still quote the original characters.
- Combined-intent rules require every stated condition near the same clause; a bare payout promise is not called profit sharing without a split request.
- The browser applies shared contextual rules, bundled text models, and browser-safe copies of the reviewed platform and URL reference lists first. With online AI help enabled, each supported submission also receives a contextual review. Strong local warnings survive a failed review.
- Multiple weak hints remain Suspicious without a stronger signal.
- Ordinary local non-matches abstain rather than certifying benign meaning.
- AI output must use supported categories and grounded source quotations. Stronger explicit danger and known reputation threats are preserved.
- No reputation match does not prove that a destination is safe.

## Repository datasets and review-signal artifacts

`backend/datasets/manifest.json` records all local text/URL datasets with source path, license status, SHA-256, row count and intended role. It is provenance documentation, not a license grant or an accuracy claim.

- Exact/near-exact matching from `A.S.E.A Taglish scam Dataset.csv` and `PhiUSIIL_Phishing_URL_Dataset.csv` remains authoritative over model scores. Text candidates are indexed by the first three tokens so a changed greeting cannot hide a known template; the existing similarity and prefix thresholds still apply.
- `lib/models/taglish-intent-model.json` and `lib/models/url-risk-model.json` are generated offline by `npm run train:datasets`. They are compact lexical review signals only, not calibrated probabilities or fraud verdicts.
- The text model uses A.S.E.A plus the collected Filipino, Hinglish, IMC25 and deduplicated SMS corpora. Several of these overlap the existing SMS model source, so their held-out scores are not independent validation of that model.
- The URL model uses only URL text from PhiUSIIL. It does not inspect page content, DNS, redirects or reputation. `dataset_phishing.csv` stays `reference-only` because it has no raw URL string.
- Exact known-address checks also use a compact PhishDestroy domain index, PAGCOR public-notice and registered-domain host lists, a small locally reviewed gambling host watchlist, and a small SEC cease-and-desist lender-name list. The registered-domain list is consulted only with an explicit gambling cue, wager call-to-action or gambling-looking address; casual wording such as "I bet you" about an ordinary link is not enough. Absence from it is Suspicious, not proof of illegality. Watchlist hosts are flagged even without gambling wording, are not attributed to PAGCOR, and remain Suspicious rather than proven illegal. These are point-in-time references; absence from any list is not approval. The generated PhishDestroy index can be rebuilt with `npm run build:url-index`. Browser-safe copies are generated into `frontend/src/engine/generated/url-reference-data.js` with `npm run build:browser-url-indexes` (or `npm run build:browser-references` from the repository root); regenerate them whenever the source lists change.
- In the API, both dataset model signals remain advisory and do not change the risk level or score. The browser adds a separate guarded `offline-text-model` review signal using the existing text model and its existing threshold: a financial/action combination or multiple meaningful learned words can support Suspicious, but cannot make a result High risk on their own. Receipt, supplied authentication-code, delivery/COD, health-appointment, protective-advice, recruiting and routine telecom contexts suppress that learned signal unless a separate active demand is present. Strong rule and known-address findings remain. The existing `sms-pattern` cap is unchanged.
- The browser also bundles exact normalized-URL fingerprints for the full source-labeled phishing class of PhiUSIIL, generated by `backend/scripts/build-browser-phishing-urls.mjs`. Conflicting URL labels are excluded. This closes a reference-coverage gap with the backend; it is not evidence of detecting previously unknown phishing sites. Full URL paths and queries are significant: a match does not block every address on a shared hosting domain, and missing from the index does not establish safety. The byte array uses bounded binary search rather than a large set of URL strings. `npm run build:browser-references` regenerates both browser reference indexes.
- Browser OCR checks join single soft line wraps, repair a URL wrapped after a hyphen, and recognize a first-person `I` misread as `|` before an auxiliary verb. Typed-message paragraph boundaries are retained. Character maps preserve the exact original text in evidence highlights; the submitted image/text is not rewritten in the result display.
- Verified official brand domains found in the compact PhishDestroy index are treated as upstream false positives and are not reported as exact known-phishing matches. `maya.ph` was the observed case on 2026-11-22; the live site is operated by Maya and the completed Safe Browsing check reported no threat. Reviewed third-party platforms are not blanket-exempt: a brand name on a user-controlled platform subdomain is still an impersonation clue. This correction does not replace online checks and does not approve a destination.
- PhiUSIIL has conflicting upstream license statements, the A.S.E.A license is unverified here, and the Vrbanic CSV has no license. Do not redistribute those raw datasets or derived artifacts until the source terms are resolved.
- Feedback is never ingested by the training script. A future opt-in path must be designed and approved separately.

## Evaluation scope

Automated regression tests use authored cases and mocked provider responses. Real OCR fixtures are synthetic screenshots, not a representative camera-image benchmark. Neither establishes population accuracy. The migration preserves behavior; it does not claim improved accuracy.

OCR uses English and Filipino language data, retries difficult reads with alternate orientations and contrast, and lets the user correct the text before a new check. QR scans can recover multiple payloads. Credential and payment records stay on the device. URL checks inspect explicit cross-site destinations in the submitted address. The checker does not visit destination pages.

Image-origin checks inspect file details first. When the user selects online visual review, the image is resized for pixel inspection. An additional configured provider can review it independently. A disagreement retains the specific observation as a possible clue. Missing provenance and an inconclusive visual review leave the origin undetermined.

Any overall accuracy claim requires a defined task and population, independently labeled untouched examples, complete online/offline pipeline evaluation, provider failures in the denominator, and per-language/task recall, false alarms, abstentions and uncertainty. Preserve source licenses and document overlap/leakage checks before using repository datasets for a new evaluation.
